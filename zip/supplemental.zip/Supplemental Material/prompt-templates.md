## Graph Traversal

### Summarization of User Response (Singular)

Model: gpt-4o-mini-2024-07-18

```text
[CONTEXT] 
The following question and answer pair is a user answer to a question regarding AI model design.

[TASK] 
Summarize the user's answer to the question, based on the information provided.

[RULE]
Do not exceed 8 words.

[DATA]
Question: {QUESTION}
User answer: {ANSWER}

[RETURN VALUE]
{RESPONSE_SCEHMA}
```

### Summarization of User Response (Plural)

Model: gpt-4o-mini-2024-07-18

```text
[CONTEXT] 
The information provided is a collection of user answers to questions.
The information is related to AI model design.

[TASK] 
Summarize the information with a focus on ${topic}.
Summarize the information in a plain text.

[RULE]
Do not exceed {WORD_LIMIT} words.
Respond in JSON.

[INFORMATION]
{LIST_OF_QUESTION_AND_ANSWER_PAIRS}

[RETURN VALUE]
{RESPONSE_SCHEMA}
```

### Supplemental Node Generation

Model: gpt-4o-mini-2024-07-18

```
[CONTEXT] 
You're AI expert that supports the user in planning a new AI project.
The user is trying to answer a challenging question and needs help elaborating on the answer.
Supportive questions are provided under [EXISTING SUPPORTIVE QUESTIONS] to help the user elaborate on the answer.

[TASK]
(1) Generate a description of how each supportive question in [EXISTING SUPPORTIVE QUESTIONS] can help the user to elaborate the answer to the expert question.
Be specific, logical, and concise in explaining the relationship.
There is total {NEIGHBOR_NODE_COUNT} supportive questions to generate a description.
If there is no supportive question, return an empty array.

(2) Suggest one more additional supportive question.
The supportive question should help the user gain a clear understanding of their own idea to answer the challenging question.
The new supportive question should not overlap with existing supportive questions.
The new topic name for the supportive question should be different from the existing topics.

[RULE]
Do not exceed 30 words for the supportive question.
Do not exceed 10 words for the description.
Do not exceed 5 words for the topic.
The supports should have the same length as the existing supportive questions.

[DATA]
Topic: {TOPIC}
Question: {QUESTION}
Existing Topics: {LIST_OF_ALL_TOPICS}

[EXISTING SUPPORTIVE QUESTIONS]
{LIST_OF_OTHER_QUESTIONS(ID, TOPIC, QUESTION)}

[RETURN VALUE]
{RESPONSE_SCHEMA}
```

## Tips and Suggestions

### Suggestion of Freeform Answer (New Question)

Model: gpt-4o-mini-2024-07-18

```text
[CONTEXT] 
You're an AI expert that provides an example answer to the question.
The user is trying to answer the question based on their own answer to other questions.
The question is related to AI model planning.

[TASK] 
Generate example answer(s) for the user to modify the current answer to the question more easily.
Follow the [GUIDANCE] and previous answers provided and provide contextually specific answers.
The number of answers to generate is {SUGGESTION_COUNT}.
Each answer should have a unique objective.
Diversify the objective and answer for each suggestion.

[RULE]
Use the information from the user's previous answers.
Try to reason the user's intention and be contextually specific.
Do not exceed {WORD_LIMIT} words for the answer.
The objective should not exceed 3 words.
Respond in JSON.

[GUIDANCE]
{TIP_GENERATED_FOR_THE_QUESTION}

[DATA]
Topic: {TOPIC}
Question: {QUESTION}
Previous Answers:
{LIST_OF_PREVIOUS_ANSWERS(ID, TOPIC, QUESTION, ANSWER)}

[OTHER SUGGESTIONS]
{LIST_OF_EXISTING_SUGGESTIONS}

[RETURN VALUE]
{RESPONSE_SCHEMA}
```

### Suggestion of Freeform Answer (Answered Question)

Model: gpt-4o-mini-2024-07-18

```text
[CONTEXT] 
You're an AI expert that provides an example answer to the question.
The user is trying to answer the question based on their own answer to other questions.
The question is related to AI model planning.

[TASK] 
Generate example answer(s) for the user to modify the current answer to the question more easily.
Follow the [GUIDANCE] and previous answers provided and provide contextually specific answers.
The number of answers to generate is {SUGGESTION_COUNT}.
Each answer should have a unique objective.
Diversify the objective and answer for each suggestion.

[RULE]
Use the information from the user's previous answers.
Try to reason the user's intention and be contextually specific.
Do not exceed {WORD_LIMIT} words for the answer.
The objective should not exceed 3 words.
Respond in JSON.

[GUIDANCE]
{TIP_GENERATED_FOR_THE_QUESTION}

[DATA]
Topic: {TOPIC}
Question: {QUESTION}
Current Answer: {USER_ANSWER}
Previous Answers:
{LIST_OF_PREVIOUS_ANSWERS(ID, TOPIC, QUESTION, ANSWER)}

[OTHER SUGGESTIONS]
{LIST_OF_EXISTING_SUGGESTIONS}

[RETURN VALUE]
{RESPONSE_SCHEMA}
```

### Suggestion of Table Answer 

Model: gpt-4o-mini-2024-07-18

```text
[CONTEXT] 
You're an AI expert who provides example answer table(s) to the question.
The user is trying to fill in the table based on their own response to other questions.
The question is related to AI model planning.

[TASK]
You're given a current full answer table in [CURRENT FULL ANSWER TABLE] with empty cells marked as empty(rowIndex, columnIndex)'.
Suggest {SUGGESTION_COUNT} possible subset answer table(s) with empty cells filled in.
Fill in the cells with contextually specific suggestions that do not exist in [CURRENT FULL ANSWER TABLE] or [EXISTING SUGGESTIONS].
Each suggestion should have a unique objective and answer table, distinctive from existing suggestions in [EXISTING SUGGESTIONS] if they exist.
Follow the [GUIDANCE] and reference previous responses in [RESPONSE TO OTHER QUESTIONS] to provide contextually specific suggestions.

[RULE]
Use the information from the user's previous responses.
Try to reason the user's intention and be contextually specific.
Do not exceed {WORD_LIMIT} words for each cell.
The content in each cell should be unique and should not repeat the same value, considering the context.
The objective should not exceed 5 words.
Respond in JSON.

[GUIDANCE]
{TIP_GENERATED_FOR_THE_QUESTION}

[DATA]
Topic: {TOPIC}
Question: {QUESTION}

[CURRENT FULL ANSWER TABLE]
{CURRENT_ANSWER_TABLE}

[RESPONSE TO OTHER QUESTIONS]
Previous Responses:
{LIST_OF_PREVIOUS_ANSWERS(ID, TOPIC, QUESTION, ANSWER)}

[EXISTING SUGGESTIONS]
{LIST_OF_EXISTING_SUGGESTIONS}

[RETURN VALUE]
objective: the objective of the answer
table: the example answer table

[RETURN FORMAT]
{RESPONSE_SCHEMA}
```

### Tip Generation (New Question)

Model: gpt-4o-2024-08-06

```text
[CONTEXT] 
You're an AI expert who contextualize the question with given information and provides guidance.
Generate guidance for the user to answer the question based on the information (previous user answers) under [INFORMATION].
The user is trying to answer the question based on their own answer to other questions.
The question is related to AI model planning.

[TASK] 
Generate guidance as word tokens for the user to answer the question based on the information provided.
Contextualize the question by referencing the user's previous answers and provide contextually specific guidance.
Mark the guidance tokens that reference the information.
The guidance should not be a direct answer to the question.

[RULE]
Select at least one piece of information.
The guidance must be tokenized as word tokens.
Each token that directly references the information should be marked with the referenced information id.
Mark the token as -1 if it is not referenced.
Follow [RETURN VALUE] for the response format.
Do not exceed 40 words for guidance.
Be concise.

[CURRENT QUESTION]
Topic: {TOPIC}
Question: {QUESTION}

[INFORMATION]
Previous Answers:
{LIST_OF_PREVIOUS_ANSWERS(ID, TOPIC, QUESTION, ANSWER)}

[RETURN VALUE]
{RESPONSE_SCHEMA}
```

### Tip Generation (Answered Question)

Model: gpt-4o-2024-08-06

```text
[CONTEXT] 
You're an AI expert that contextualize the question with given information and provide the guidance for modifying the current answer.
Generate guidance for the user to modify the current answer to the question based on the information (previous user answers) under [INFORMATION].
The user is trying to modify the answer for the question based on their own answer to other questions.
The question is related to AI model planning.

[TASK] 
Generate guidance as word tokens for the user to modify the current answer to the question based on the information provided.
Contextualize the question by referencing the user's previous answers and provide contextually specific guidance.
Mark the guidance tokens that reference the information.
The guidance should not be a direct answer to the question.

[RULE]
Select at least one piece of information.
The guidance must be tokenized as word tokens.
Each token that directly references the information should be marked with the referenced information id.
Mark the token as -1 if it is not referenced.
Follow [RETURN VALUE] for the response format.
Do not exceed 40 words for guidance.
Be concise.

[CURRENT QUESTION]
Topic: {TOPIC}
Question: {QUESTION}
Current Answer: ${CURRENT_ANSWER}

[INFORMATION]
Previous Answers:
{LIST_OF_PREVIOUS_ANSWERS(ID, TOPIC, QUESTION, ANSWER)}

[RETURN VALUE]
{RESPONSE_SCHEMA}
```

## Overview Panel

### Copy Dataset Count

Model: gpt-4o-mini-2024-07-18

```text
[CONTEXT] 
Dataset count inferences based on the clues provided. 

[TASK] 
Make inference on the (total dataset size, additional dataset size, and current dataset size) based on the clues provided.
You can make up a reasonable value if the clues contradict each other.

[DATA]
Total dataset size clue: ${TOTAL_DATASET_SIZE}
Additional dataset size clue: ${ADDITIONAL_DATASET_SIZE}
Current dataset size clue: ${CURRENT_DATASET_SIZE}

[RETURN VALUE]
{RESPONSE_SCHEMA}
```

### Simulate Dataset

Model: gpt-4o-mini-2024-07-18

```text
[CONTEXT] 
Dataset simulation for AI model development given column names and descriptions 

[TASK] 
Simulate the dataset based on the column names and descriptions provided.
Simulate a total of three rows.

[RULE]
Each value should be a plain string.

[DATA]
${params.items
  .map(
    (item, i) =>
      `(Column ${i}: ${item.name} - Description: ${item.description}, Format: ${item.format})`
  )
  .join("\n")}

[RETURN VALUE]
{RESPONSE_SCHEMA}
```

### User Response Summarization (Topic-centered) 

Model: gpt-4o-mini-2024-07-18

```text
[CONTEXT]
You're a helpful assistant that infers matching answers to the topic given information.
The information is a user's answers to questions asking about the AI model design plan.
The topic is {TOPIC}.

[TASK]
Infer the matching answer to the topic based on the information provided.
You can reason a reasonable answer if the information is not clear.

[RULE]
Do not exceed {WORD_LIMIT} words for the response.
Start with uppercase for each answer.

[INFORMATION]
{LIST_OF_PREVIOUS_ANSWERS(QUESTION, ANSWER)}

[RETURN VALUE]
{RESPONSE_SCHEMA}
```

### Timeline Organization

Model: gpt-4o-mini-2024-07-18

```
[TASK] 
The information is AI project milestones.
Order the milestones chronologically based on the provided descriptions.
Eariler milestones should come first.

[RULE]
Return the chronological order of the milestones.
Use the id to identify the milestones.
Respond in JSON.

[INFORMATION]
{LIST_OF_MILESTONES (ID, MILESTONE, DATE)}

[RESPONSE STRUCTURE]
{RESPONSE_SCHEMA}
```

## AI Chatbot

### Chatbot Response

Model: gpt-4o-2024-08-06

```
[CONTEXT]
You're a helpful assistant in planning a new AI system.
As an assistant, assist the user in planning the AI system by responding to the message.
The user already provided some information regarding the AI system design.

[TASK]
Respond to the user's message based on the provided information.
Utilize the information provided in [INFORMATION] to make the response more contextually specific.

[RULE]
Be contextually specific and provide relevant assistance.
Be concise and short in your response.

[INFORMATION]
{LIST_OF_ALL_QUESTIONS(ID, TOPIC, QUESTION, ANSWER)}
```